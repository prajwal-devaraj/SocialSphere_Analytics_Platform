"""
Tests for the FastAPI ingestion service endpoints. Mocks the S3/MinIO
client so these run without a real MinIO instance.

Run with: pytest tests/test_ingestion_api.py -v
"""

import sys
import os
import unittest.mock as mock

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "ingestion_service"))

import pytest


@pytest.fixture
def client():
    # Patch boto3.client before importing main/storage so EventStore's
    # __init__ (which creates an S3 client + checks the bucket) never hits
    # a real network call during tests.
    import boto3

    def fake_client(*args, **kwargs):
        m = mock.MagicMock()
        m.head_bucket.return_value = {}
        return m

    with mock.patch.object(boto3, "client", side_effect=fake_client):
        from fastapi.testclient import TestClient
        import main
        return TestClient(main.app)


SAMPLE_EVENT = {
    "event_id": "evt_apitest1",
    "user_id": "user_1",
    "session_id": "sess_1",
    "event_type": "post_liked",
    "event_timestamp": "2026-06-28T14:32:10Z",
    "platform": "ios",
    "device_type": "mobile",
    "country": "US",
    "city": "New York",
    "app_version": "2.4.1",
    "revenue": 0.0,
}


def test_health_check(client):
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "healthy"


def test_metrics_endpoint(client):
    r = client.get("/metrics")
    assert r.status_code == 200
    body = r.json()
    assert "total_ingested" in body
    assert "total_flushed" in body


def test_post_single_event(client):
    r = client.post("/events", json=SAMPLE_EVENT)
    assert r.status_code == 200
    body = r.json()
    assert body["accepted"] == 1
    assert body["event_id"] == "evt_apitest1"


def test_post_event_batch(client):
    batch = {
        "events": [
            SAMPLE_EVENT,
            dict(SAMPLE_EVENT, event_id="evt_apitest2"),
            dict(SAMPLE_EVENT, event_id="evt_apitest3"),
        ]
    }
    r = client.post("/events/batch", json=batch)
    assert r.status_code == 200
    assert r.json()["accepted"] == 3


def test_post_invalid_event_rejected(client):
    bad = dict(SAMPLE_EVENT, event_type="totally_made_up_event")
    r = client.post("/events", json=bad)
    assert r.status_code == 422


def test_post_empty_batch_rejected(client):
    r = client.post("/events/batch", json={"events": []})
    assert r.status_code == 422
