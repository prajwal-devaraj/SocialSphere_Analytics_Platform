"""
Tests for the PySpark transformation logic in spark_jobs/. Uses a local
Spark session and small in-memory DataFrames so these run fast without
needing real bronze/silver data on disk.

Run with: pytest tests/test_spark_transformations.py -v
"""

import sys
import os
from datetime import datetime, timedelta

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "spark_jobs"))

import pytest
from pyspark.sql import SparkSession


@pytest.fixture(scope="module")
def spark():
    spark = (
        SparkSession.builder.appName("test_spark_transformations")
        .master("local[1]")
        .config("spark.sql.session.timeZone", "UTC")
        .getOrCreate()
    )
    yield spark
    spark.stop()


def test_clean_events_drops_negative_revenue(spark):
    from bronze_to_silver import clean_events

    rows = [
        {
            "event_id": "evt_1", "user_id": "u1", "session_id": "s1",
            "event_type": "purchase_completed", "event_timestamp": "2026-06-20T10:00:00Z",
            "platform": "ios", "device_type": "mobile", "country": "US",
            "revenue": -5.0,
        },
        {
            "event_id": "evt_2", "user_id": "u2", "session_id": "s2",
            "event_type": "purchase_completed", "event_timestamp": "2026-06-20T10:00:00Z",
            "platform": "ios", "device_type": "mobile", "country": "US",
            "revenue": 9.99,
        },
    ]
    df = spark.createDataFrame(rows)
    clean, report = clean_events(df)
    assert report["dropped_negative_revenue"] == 1
    assert clean.count() == 1
    assert clean.collect()[0]["revenue"] == 9.99


def test_clean_events_drops_duplicates(spark):
    from bronze_to_silver import clean_events

    rows = [
        {
            "event_id": "evt_dup", "user_id": "u1", "session_id": "s1",
            "event_type": "post_liked", "event_timestamp": "2026-06-20T10:00:00Z",
            "platform": "ios", "device_type": "mobile", "country": "US", "revenue": 0.0,
        },
        {
            "event_id": "evt_dup", "user_id": "u1", "session_id": "s1",
            "event_type": "post_liked", "event_timestamp": "2026-06-20T10:00:01Z",
            "platform": "ios", "device_type": "mobile", "country": "US", "revenue": 0.0,
        },
    ]
    df = spark.createDataFrame(rows)
    clean, report = clean_events(df)
    assert report["dropped_duplicates"] == 1
    assert clean.count() == 1


def test_clean_events_drops_invalid_event_type(spark):
    from bronze_to_silver import clean_events

    rows = [
        {
            "event_id": "evt_bad", "user_id": "u1", "session_id": "s1",
            "event_type": "made_up_event", "event_timestamp": "2026-06-20T10:00:00Z",
            "platform": "ios", "device_type": "mobile", "country": "US", "revenue": 0.0,
        },
    ]
    df = spark.createDataFrame(rows)
    clean, report = clean_events(df)
    assert report["dropped_bad_event_type"] == 1
    assert clean.count() == 0


def test_clean_events_drops_missing_user_id(spark):
    from bronze_to_silver import clean_events
    from pyspark.sql.types import StructType, StructField, StringType, DoubleType

    schema = StructType([
        StructField("event_id", StringType()),
        StructField("user_id", StringType()),
        StructField("session_id", StringType()),
        StructField("event_type", StringType()),
        StructField("event_timestamp", StringType()),
        StructField("platform", StringType()),
        StructField("device_type", StringType()),
        StructField("country", StringType()),
        StructField("revenue", DoubleType()),
    ])
    rows = [("evt_1", None, "s1", "post_liked", "2026-06-20T10:00:00Z", "ios", "mobile", "US", 0.0)]
    df = spark.createDataFrame(rows, schema=schema)
    clean, report = clean_events(df)
    assert report["dropped_missing_ids"] == 1


def test_daily_active_users_counts_distinct_users(spark):
    from silver_to_gold_daily_metrics import compute_daily_active_users
    from pyspark.sql.types import StructType, StructField, StringType, DateType
    from datetime import date

    schema = StructType([
        StructField("user_id", StringType()),
        StructField("event_date", DateType()),
    ])
    rows = [
        ("u1", date(2026, 6, 20)),
        ("u1", date(2026, 6, 20)),  # same user, same day -> counted once
        ("u2", date(2026, 6, 20)),
        ("u3", date(2026, 6, 21)),
    ]
    df = spark.createDataFrame(rows, schema=schema)
    result = compute_daily_active_users(df).orderBy("event_date").collect()
    assert result[0]["event_date"] == date(2026, 6, 20)
    assert result[0]["daily_active_users"] == 2
    assert result[1]["daily_active_users"] == 1


def test_funnel_enforces_strict_step_order(spark):
    """
    Regression test for the bug caught during manual testing: a user who
    reaches a later step (post_liked) WITHOUT having reached the
    immediately preceding step (post_created) in order must NOT count
    toward that later step.
    """
    from funnel_analysis_job import build_funnel_metrics
    from pyspark.sql.types import StructType, StructField, StringType, DateType, TimestampType
    from datetime import date

    schema = StructType([
        StructField("user_id", StringType()),
        StructField("event_type", StringType()),
        StructField("event_timestamp", TimestampType()),
        StructField("event_date", DateType()),
    ])

    base_day = datetime(2026, 6, 20, 10, 0, 0)
    rows = [
        # user_1: full proper funnel in order
        ("user_1", "user_signup", base_day, date(2026, 6, 20)),
        ("user_1", "profile_view", base_day + timedelta(minutes=1), date(2026, 6, 20)),
        ("user_1", "post_created", base_day + timedelta(minutes=2), date(2026, 6, 20)),
        ("user_1", "post_liked", base_day + timedelta(minutes=3), date(2026, 6, 20)),
        # user_2: signs up, then likes a post WITHOUT ever creating one or viewing profile
        ("user_2", "user_signup", base_day, date(2026, 6, 20)),
        ("user_2", "post_liked", base_day + timedelta(minutes=1), date(2026, 6, 20)),
    ]
    df = spark.createDataFrame(rows, schema=schema)
    result = build_funnel_metrics(df).collect()

    by_step = {r["funnel_step"]: r["users_reached"] for r in result}
    assert by_step["user_signup"] == 2
    assert by_step["profile_view"] == 1  # only user_1
    assert by_step["post_created"] == 1  # only user_1
    assert by_step["post_liked"] == 1    # only user_1 -- user_2 must NOT count here

    # Also verify no row has users_reached greater than the previous step
    # (i.e. no negative drop-off rates / impossible funnel growth)
    ordered = sorted(result, key=lambda r: r["step_order"])
    for i in range(1, len(ordered)):
        assert ordered[i]["users_reached"] <= ordered[i - 1]["users_reached"]
        assert 0.0 <= ordered[i]["drop_off_rate"] <= 1.0
