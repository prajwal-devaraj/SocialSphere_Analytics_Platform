"""
Tests for the ProductEvent Pydantic schema used by the ingestion service.
Run with: pytest tests/test_event_schema.py -v
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "ingestion_service"))

import pytest
from pydantic import ValidationError
from models import ProductEvent

VALID_EVENT = {
    "event_id": "evt_12345",
    "user_id": "user_987",
    "session_id": "sess_555",
    "event_type": "post_liked",
    "event_timestamp": "2026-06-28T14:32:10Z",
    "platform": "ios",
    "device_type": "mobile",
    "country": "US",
    "city": "New York",
    "app_version": "2.4.1",
    "page": "home_feed",
    "feature": "like_button",
    "post_id": "post_222",
    "creator_id": "user_111",
    "duration_seconds": 18,
    "revenue": 0.0,
    "metadata": {"experiment_group": "B", "referrer": "notification"},
}


def test_valid_event_passes():
    event = ProductEvent(**VALID_EVENT)
    assert event.event_id == "evt_12345"
    assert event.event_type == "post_liked"


def test_invalid_event_type_rejected():
    bad = dict(VALID_EVENT, event_type="not_a_real_event")
    with pytest.raises(ValidationError):
        ProductEvent(**bad)


def test_negative_revenue_rejected():
    bad = dict(VALID_EVENT, revenue=-5.0)
    with pytest.raises(ValidationError):
        ProductEvent(**bad)


def test_missing_user_id_rejected():
    bad = dict(VALID_EVENT)
    del bad["user_id"]
    with pytest.raises(ValidationError):
        ProductEvent(**bad)


def test_empty_event_id_rejected():
    bad = dict(VALID_EVENT, event_id="")
    with pytest.raises(ValidationError):
        ProductEvent(**bad)


def test_future_timestamp_rejected():
    bad = dict(VALID_EVENT, event_timestamp="2099-01-01T00:00:00Z")
    with pytest.raises(ValidationError):
        ProductEvent(**bad)


def test_optional_fields_can_be_omitted():
    minimal = dict(VALID_EVENT)
    for optional_field in ["page", "feature", "post_id", "creator_id", "duration_seconds", "metadata"]:
        minimal.pop(optional_field, None)
    event = ProductEvent(**minimal)
    assert event.revenue == 0.0


def test_negative_duration_rejected():
    bad = dict(VALID_EVENT, duration_seconds=-10)
    with pytest.raises(ValidationError):
        ProductEvent(**bad)
