"""
Tests for the data quality check functions in data_quality/validation_rules.py.
Uses small in-memory Spark DataFrames to exercise each check independently.

Run with: pytest tests/test_data_quality.py -v
"""

import sys
import os
from datetime import datetime, timedelta, date

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "data_quality"))

import pytest
from pyspark.sql import SparkSession
from pyspark.sql.types import (
    StructType, StructField, StringType, DoubleType, TimestampType, DateType,
)


@pytest.fixture(scope="module")
def spark():
    spark = (
        SparkSession.builder.appName("test_data_quality")
        .master("local[1]")
        .config("spark.sql.session.timeZone", "UTC")
        .getOrCreate()
    )
    yield spark
    spark.stop()


def _make_df(spark, rows, with_revenue=True, with_date=True):
    fields = [
        StructField("event_id", StringType()),
        StructField("user_id", StringType()),
        StructField("event_type", StringType()),
        StructField("event_timestamp", TimestampType()),
    ]
    if with_revenue:
        fields.append(StructField("revenue", DoubleType()))
    if with_date:
        fields.append(StructField("event_date", DateType()))
    schema = StructType(fields)
    return spark.createDataFrame(rows, schema=schema)


def test_check_no_null_event_ids_passes_when_clean(spark):
    from validation_rules import check_no_null_event_ids

    df = _make_df(spark, [
        ("evt_1", "u1", "post_liked", datetime(2026, 6, 20), 0.0, date(2026, 6, 20)),
    ])
    result = check_no_null_event_ids(df)
    assert result["passed"] is True


def test_check_no_null_event_ids_fails_on_null(spark):
    from validation_rules import check_no_null_event_ids

    df = _make_df(spark, [
        (None, "u1", "post_liked", datetime(2026, 6, 20), 0.0, date(2026, 6, 20)),
        ("evt_2", "u2", "post_liked", datetime(2026, 6, 20), 0.0, date(2026, 6, 20)),
    ])
    result = check_no_null_event_ids(df)
    assert result["passed"] is False
    assert "1 rows" in result["detail"]


def test_check_no_duplicate_event_ids(spark):
    from validation_rules import check_no_duplicate_event_ids

    df = _make_df(spark, [
        ("evt_1", "u1", "post_liked", datetime(2026, 6, 20), 0.0, date(2026, 6, 20)),
        ("evt_1", "u1", "post_liked", datetime(2026, 6, 20), 0.0, date(2026, 6, 20)),
    ])
    result = check_no_duplicate_event_ids(df)
    assert result["passed"] is False


def test_check_valid_event_types_only(spark):
    from validation_rules import check_valid_event_types_only

    df = _make_df(spark, [
        ("evt_1", "u1", "totally_fake_event", datetime(2026, 6, 20), 0.0, date(2026, 6, 20)),
    ])
    result = check_valid_event_types_only(df)
    assert result["passed"] is False


def test_check_revenue_not_negative(spark):
    from validation_rules import check_revenue_not_negative

    df = _make_df(spark, [
        ("evt_1", "u1", "purchase_completed", datetime(2026, 6, 20), -9.99, date(2026, 6, 20)),
    ])
    result = check_revenue_not_negative(df)
    assert result["passed"] is False


def test_check_timestamps_not_future(spark):
    from validation_rules import check_timestamps_not_future

    future = datetime.now() + timedelta(days=5)
    df = _make_df(spark, [
        ("evt_1", "u1", "post_liked", future, 0.0, date(2026, 6, 20)),
    ])
    result = check_timestamps_not_future(df)
    assert result["passed"] is False


def test_run_all_checks_returns_summary(spark, tmp_path):
    from validation_rules import run_all_checks

    df = _make_df(spark, [
        ("evt_1", "u1", "post_liked", datetime(2026, 6, 20), 0.0, date(2026, 6, 20)),
        ("evt_2", "u2", "post_liked", datetime(2026, 6, 21), 0.0, date(2026, 6, 21)),
    ])
    silver_path = str(tmp_path / "silver_test")
    df.write.mode("overwrite").parquet(silver_path)

    report = run_all_checks(silver_path)
    assert "checks" in report
    assert "summary" in report
    assert len(report["checks"]) == 7
